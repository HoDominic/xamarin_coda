﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex01.Models
{
    public class CodaPage
    {
    }
}
